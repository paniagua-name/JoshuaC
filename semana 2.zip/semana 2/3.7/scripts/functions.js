function calcularBeca() {
    let edad = parseInt(document.getElementById("edad").value);
    let promedio = parseFloat(document.getElementById("promedio").value);
    let resultado = document.getElementById("resultado");
    let mensaje = "";

    if (edad > 18) {
        if (promedio >= 9) mensaje = "Monto de la beca: $2000.00";
        else if (promedio >= 7.5) mensaje = "Monto de la beca: $1000.00";
        else if (promedio >= 6.0) mensaje = "Monto de la beca: $500.00";
        else mensaje = "Carta de invitación enviada: Te incitamos a estudiar más el próximo ciclo escolar.";
    } else { // 18 años o menos
        if (promedio >= 9) mensaje = "Monto de la beca: $3000.00";
        else if (promedio >= 8) mensaje = "Monto de la beca: $2000.00";
        else if (promedio >= 6) mensaje = "Monto de la beca: $100.00";
        else mensaje = "Carta de invitación enviada.";
    }

    resultado.textContent = mensaje;
}
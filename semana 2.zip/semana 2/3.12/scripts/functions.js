function calcularSueldoComplejo() {
    let horas = parseFloat(document.getElementById("horas").value);
    let pago = parseFloat(document.getElementById("pago").value);
    let resultado = document.getElementById("resultado");
    let sueldo = 0;

    if (horas > 50) {
        resultado.textContent = "Error: Trabajar más de 50 horas semanales no está permitido.";
        return;
    }

    if (horas <= 40) {
        sueldo = horas * pago;
    } else if (horas <= 45) {
        let horasExtraDobles = horas - 40;
        sueldo = (40 * pago) + (horasExtraDobles * pago * 2);
    } else { // Entre 46 y 50 horas
        let horasExtraDobles = 5; // De la 41 a la 45 son 5 horas
        let horasExtraTriples = horas - 45;
        sueldo = (40 * pago) + (horasExtraDobles * pago * 2) + (horasExtraTriples * pago * 3);
    }

    resultado.textContent = `El sueldo neto semanal permitido es de: $${sueldo.toFixed(2)}`;
}
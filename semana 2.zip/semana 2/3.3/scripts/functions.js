function elegirRegalo() {
    let dinero = parseFloat(document.getElementById("presupuesto").value);
    let resultado = document.getElementById("resultado");
    let regalo = "";

    if (dinero <= 10) {
        regalo = "Tarjeta";
    } else if (dinero > 10 && dinero <= 100) {
        regalo = "Chocolates";
    } else if (dinero > 100 && dinero <= 250) {
        regalo = "Flores";
    } else {
        regalo = "Anillo";
    }

    resultado.textContent = `Puedes regalar: ${regalo}`;
}
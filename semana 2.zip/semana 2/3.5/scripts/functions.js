function calcularMenor() {
    let nom1 = document.getElementById("n1").value;
    let edad1 = parseInt(document.getElementById("e1").value);
    
    let nom2 = document.getElementById("n2").value;
    let edad2 = parseInt(document.getElementById("e2").value);
    
    let nom3 = document.getElementById("n3").value;
    let edad3 = parseInt(document.getElementById("e3").value);
    
    let resultado = document.getElementById("resultado");

    let nombreMenor = nom1;
    let edadMenor = edad1;

    if (edad2 < edadMenor) {
        edadMenor = edad2;
        nombreMenor = nom2;
    }
    if (edad3 < edadMenor) {
        edadMenor = edad3;
        nombreMenor = nom3;
    }

    resultado.textContent = `La persona de menor edad es ${nombreMenor} con ${edadMenor} años.`;
}
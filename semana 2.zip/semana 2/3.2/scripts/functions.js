function calcularSueldo() {
    let horas = parseFloat(document.getElementById("horas").value);
    let pago = parseFloat(document.getElementById("pago").value);
    let resultado = document.getElementById("resultado");
    let sueldo = 0;

    if (horas <= 40) {
        sueldo = horas * pago;
    } else {
        let horasNormales = 40;
        let horasExtra = horas - 40;
        sueldo = (horasNormales * pago) + (horasExtra * pago * 2);
    }

    resultado.textContent = `El sueldo semanal es de: $${sueldo.toFixed(2)}`;
}
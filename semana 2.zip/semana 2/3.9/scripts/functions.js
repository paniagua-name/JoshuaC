function calcularSeguro() {
    let tipo = document.getElementById("tipo").value;
    let alcohol = document.getElementById("alcohol").checked;
    let lentes = document.getElementById("lentes").checked;
    let enfermedad = document.getElementById("enfermedad").checked;
    let edad = parseInt(document.getElementById("edad").value);
    let resultado = document.getElementById("resultado");

    let costoBase = (tipo === "A") ? 1200 : 950;
    let cargosPorcentaje = 0;

    if (alcohol) cargosPorcentaje += 0.10;
    if (lentes) cargosPorcentaje += 0.05;
    if (enfermedad) cargosPorcentaje += 0.05;
    
    // Cargo por edad
    if (edad > 40) {
        cargosPorcentaje += 0.20;
    } else {
        cargosPorcentaje += 0.10;
    }

    let totalCargos = costoBase * cargosPorcentaje;
    let costoTotal = costoBase + totalCargos;

    resultado.innerHTML = `Costo Base: $${costoBase.toFixed(2)}<br>
                           Total por Cargos Extra: $${totalCargos.toFixed(2)} (${cargosPorcentaje * 100}%)<br>
                           <strong>Costo Total de la Póliza: $${costoTotal.toFixed(2)}</strong>`;
}
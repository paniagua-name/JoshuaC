function costoFinal() {
    let num1 = parseFloat(document.getElementById("Costo").value);
    let num2 = parseInt(document.getElementById("Lugar").value, 10);
    let resultado = document.getElementById("resultado");
    let num3;

    if (isNaN(num1) || num1 <= 0) {
        resultado.textContent = "Por favor, ingresa un costo por kilómetro válido.";
        return;
    }

    if (num2 === 1) {
        num3 = 750;
    } else if (num2 === 2) {
        num3 = 800;
    } else if (num2 === 3) {
        num3 = 1200;
    } else if (num2 === 4) {
        num3 = 1800;
    } else {
        resultado.textContent = "Destino inválido, debes ingresar un número del 1 al 4 o considerar quedarte en casa.";
        return;
    }

    // Se calcula el costo total considerando ida y vuelta (* 2)
    const result = num1 * num3 * 2;
    resultado.innerHTML = `<strong>El costo total del pasaje (ida y vuelta) es: $${result.toFixed(2)}</strong>`;
}
function calcularBonoFijo() {
    let anios = parseInt(document.getElementById("anios").value);
    let resultado = document.getElementById("resultado");
    let bono = 0;

    if (anios >= 1 && anios <= 5) {
        bono = anios * 100; // 1 año=$100, 2 años=$200, etc.
    } else if (anios > 5) {
        bono = 1000;
    } else {
        bono = 0;
    }

    resultado.textContent = `El bono correspondiente es de: $${bono}.00`;
}
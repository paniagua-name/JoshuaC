function calcularDescuento() {
    let precio = parseFloat(document.getElementById("precio").value);
    let resultado = document.getElementById("resultado");
    let porcentajeDesc = 0;

    if (precio >= 200) {
        porcentajeDesc = 0.15;
    } else if (precio > 100 && precio < 200) {
        porcentajeDesc = 0.12;
    } else {
        porcentajeDesc = 0.10;
    }

    let descuento = precio * porcentajeDesc;
    let precioFinal = precio - descuento;

    resultado.innerHTML = `Descuento aplicado: $${descuento.toFixed(2)} (${porcentajeDesc * 100}%)<br>
                           Precio Final: $${precioFinal.toFixed(2)}`;
}
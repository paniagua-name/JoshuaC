function verificarVoto() {
    let edad = parseInt(document.getElementById("edad").value);
    let resultado = document.getElementById("resultado");

    if (isNaN(edad) || edad < 0) {
        resultado.textContent = "Por favor, ingresa una edad válida.";
        return;
    }

    if (edad >= 18) {
        resultado.textContent = "Puedes votar en las próximas elecciones.";
    } else {
        resultado.textContent = "No cumples con la edad mínima para votar.";
    }
}
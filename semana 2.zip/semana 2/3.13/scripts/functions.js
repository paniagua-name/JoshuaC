function calcularPasaje() {
    let alumnos = parseInt(document.getElementById("alumnos").value);
    let resultado = document.getElementById("resultado");
    let costoPorAlumno = 0;

    if (alumnos <= 0 || isNaN(alumnos)) {
        resultado.textContent = "Por favor, introduce un número válido de alumnos.";
        return;
    }

    if (alumnos > 100) {
        costoPorAlumno = 20;
    } else if (alumnos >= 50 && alumnos <= 100) {
        costoPorAlumno = 35;
    } else if (alumnos >= 20 && alumnos <= 49) {
        costoPorAlumno = 40;
    } else {
        costoPorAlumno = 70;
    }

    let costoTotalAutobus = alumnos * costoPorAlumno;

    resultado.innerHTML = `Costo por cada alumno: $${costoPorAlumno}.00<br>
                           <strong>Costo total del autobús para el grupo: $${costoTotalAutobus}.00</strong>`;
}
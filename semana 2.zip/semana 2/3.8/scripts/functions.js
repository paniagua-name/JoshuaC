function calcularBono() {
    let sueldo = parseFloat(document.getElementById("sueldo").value);
    let anti = parseFloat(document.getElementById("antiguedad").value);
    let resultado = document.getElementById("resultado");

    // Bono por antigüedad
    let bonoAnti = 0;
    if (anti > 2 && anti < 5) {
        bonoAnti = sueldo * 0.20;
    } else if (anti >= 5) {
        bonoAnti = sueldo * 0.30;
    }

    // Bono por sueldo
    let bonoSueldo = 0;
    if (sueldo < 1000) {
        bonoSueldo = sueldo * 0.25;
    } else if (sueldo >= 1000 && sueldo <= 3500) {
        bonoSueldo = sueldo * 0.15;
    } else {
        bonoSueldo = sueldo * 0.10;
    }

    // Asignar el mayor
    let bonoFinal = Math.max(bonoAnti, bonoSueldo);

    resultado.innerHTML = `Bono por Antigüedad calculado: $${bonoAnti.toFixed(2)}<br>
                           Bono por Sueldo calculado: $${bonoSueldo.toFixed(2)}<br>
                           <strong>Bono Máximo Asignado: $${bonoFinal.toFixed(2)}</strong>`;
}